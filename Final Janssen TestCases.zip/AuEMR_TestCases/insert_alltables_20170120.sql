--TRUNCATE TABLE _version;
TRUNCATE TABLE allergy;
--TRUNCATE TABLE allergy_mapping_lk;
TRUNCATE TABLE doctor_speciality;
--TRUNCATE TABLE fo_product;
TRUNCATE TABLE biometric;
--TRUNCATE TABLE biometric_concept_lk;
TRUNCATE TABLE contact;
TRUNCATE TABLE contact_add_data;
--TRUNCATE TABLE diagnosis_mapping;
--TRUNCATE TABLE diagnosis_mapping_snomed;
TRUNCATE TABLE diagnostic;
TRUNCATE TABLE diagnostic_add_data;
TRUNCATE TABLE diagnostic_contact;
TRUNCATE TABLE doctor;
TRUNCATE TABLE doctor_panel;
TRUNCATE TABLE doctor_practice;
TRUNCATE TABLE filled_questionnaire;
TRUNCATE TABLE galenic;
TRUNCATE TABLE geo_subdivision;
--TRUNCATE TABLE icd10_concept_lk;
TRUNCATE TABLE immunization;
--TRUNCATE TABLE immunization_mapping;
--TRUNCATE TABLE list;
--TRUNCATE TABLE list_code;
--TRUNCATE TABLE locale_list;
--TRUNCATE TABLE locale_list_code;
TRUNCATE TABLE panel;
TRUNCATE TABLE patient;
TRUNCATE TABLE patient_medical_hist;
TRUNCATE TABLE patient_practice;
TRUNCATE TABLE practice;
TRUNCATE TABLE prescription;
TRUNCATE TABLE product_hist;
--TRUNCATE TABLE source_to_concept_map;
--TRUNCATE TABLE test_mapping;
TRUNCATE TABLE test_prescribed;
TRUNCATE TABLE test_result;
--TRUNCATE TABLE test_unit_mapping;
--TRUNCATE TABLE voc_source_to_standard_lk;

-- 1. Condition Occurrence
--
-- 1.0 basic diagnositic_contact ICD10 to condition_occurrence test: 0S8600 [Test ID: 1]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '1', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-04', '2', '4018', '1', '20471', '141', '1', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-04', '2', '376870', '1', '100', '0', '63745', '0');
--
-- 1.1 basic diagnositic_contact ICD10 to condition_occurrence test: 0S3350 [Test ID: 2]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '4', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-07', '5', '4018', '1', '20471', '141', '4', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-07', '5', '199619', '1', '100', '0', '63745', '0');
--
-- 1.2 basic diagnositic_contact ICD10 to condition_occurrence test: 0K0760 [Test ID: 3]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '7', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-10', '8', '4018', '1', '20471', '141', '7', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-10', '8', '375223', '1', '100', '0', '63745', '0');
--
-- 1.3 basic diagnositic_contact ICD10 to condition_occurrence test: 0K0510 [Test ID: 4]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '10', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-13', '11', '4018', '1', '20471', '141', '10', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-13', '11', '4905', '1', '100', '0', '63745', '0');
--
-- 1.4 2 diagnostic_contact dia_ids map to one  ICD10, keep 1 condition_occurrence record [Test ID: 5]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '13', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-16', '14', '4018', '1', '20471', '141', '13', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-16', '14', '30772', '1', '100', '0', '63745', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-16', '14', '9754', '1', '100', '0', '63745', '0');
--
-- 1.5 basic SNOMED to condition_occurrence test [Test ID: 6]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '16', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-19', '17', '4018', '1', '20471', '141', '16', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-19', '17', '26444', '1', '100', '0', '63745', '0');
--
-- 1.6 8532-specific diagnostic_contact SNOMED to condition_occurrence test: 6738008 [Test ID: 7]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '19', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-22', '20', '4018', '1', '20471', '141', '19', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-22', '20', '165212', '1', '100', '0', '63745', '0');
--
-- 1.7 8507-specific diagnostic_contact SNOMED to condition_occurrence test: 2904007 [Test ID: 8]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '1', '22', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-25', '23', '4018', '1', '20471', '141', '22', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-25', '23', '11414', '1', '100', '0', '63745', '0');
--
-- 1.8 gender-specific diagnostic_contact SNOMED record doesnt match patient gender, no condition_occurrence record [Test ID: 9]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '25', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-28', '26', '4018', '1', '20471', '141', '25', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-28', '26', '11414', '1', '100', '0', '63745', '0');
--
-- 1.9 basic diagnostic_contact condition_occurrence record with provider_id, condition_type_concept_id [Test ID: 10]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '28', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('31', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-31', '29', '4018', '1', '20471', '31', '28', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-31', '29', '117164', '1', '100', '0', '63745', '0');
--
-- 1.10 diganostic_contact record doesnt map to ICD10/SNOMED [Test ID: 11]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '32', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-04', '33', '4018', '1', '20471', '141', '32', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-04', '33', '999999', '1', '100', '0', '63745', '0');
--
-- 1.11 Record with dia 102268 doesnt more to condition_occurrence [Test ID: 12]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '35', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-07', '36', '4018', '1', '20471', '141', '35', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-07', '36', '102268', '1', '100', '0', '63745', '0');
--
-- 1.12 Record with dia 251220 doesnt more to condition_occurrence [Test ID: 13]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '38', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-10', '39', '4018', '1', '20471', '141', '38', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-10', '39', '251220', '1', '100', '0', '63745', '0');
--
-- 1.13 Record with dia 134016 doesnt more to condition_occurrence [Test ID: 14]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '41', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-13', '42', '4018', '1', '20471', '141', '41', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-13', '42', '134016', '1', '100', '0', '63745', '0');
--
-- 1.14 Record with dia 3357 doesnt more to condition_occurrence [Test ID: 15]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '44', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-16', '45', '4018', '1', '20471', '141', '44', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-16', '45', '3357', '1', '100', '0', '63745', '0');
--
-- 1.15 Record with dia 4096 doesnt more to condition_occurrence [Test ID: 16]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '47', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-19', '48', '4018', '1', '20471', '141', '47', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-19', '48', '4096', '1', '100', '0', '63745', '0');
--
-- 1.16 Record with dia 102340 doesnt more to condition_occurrence [Test ID: 17]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '50', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-22', '51', '4018', '1', '20471', '141', '50', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-22', '51', '102340', '1', '100', '0', '63745', '0');
--
-- 1.17 Record with dia 225898 doesnt more to condition_occurrence [Test ID: 18]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '53', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-25', '54', '4018', '1', '20471', '141', '53', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-25', '54', '225898', '1', '100', '0', '63745', '0');
--
-- 1.18 Record with dia 95314 doesnt more to condition_occurrence [Test ID: 19]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '56', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-02-28', '57', '4018', '1', '20471', '141', '56', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-02-28', '57', '95314', '1', '100', '0', '63745', '0');
--
-- 1.19 Record with dia 740076 doesnt more to condition_occurrence [Test ID: 20]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '59', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-03', '60', '4018', '1', '20471', '141', '59', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-03', '60', '740076', '1', '100', '0', '63745', '0');
--
-- 1.20 Record with dia 102220 doesnt more to condition_occurrence [Test ID: 21]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '62', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-06', '63', '4018', '1', '20471', '141', '62', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-06', '63', '102220', '1', '100', '0', '63745', '0');
--
-- 1.21 Record with dia 95313 doesnt more to condition_occurrence [Test ID: 22]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '65', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-09', '66', '4018', '1', '20471', '141', '65', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-09', '66', '95313', '1', '100', '0', '63745', '0');
--
-- 1.22 Record with dia 102228 doesnt more to condition_occurrence [Test ID: 23]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '68', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-12', '69', '4018', '1', '20471', '141', '68', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-12', '69', '102228', '1', '100', '0', '63745', '0');
--
-- 1.23 Record with dia 228447 doesnt more to condition_occurrence [Test ID: 24]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '71', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-15', '72', '4018', '1', '20471', '141', '71', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-15', '72', '228447', '1', '100', '0', '63745', '0');
--
-- 1.24 Record with dia 102214 doesnt more to condition_occurrence [Test ID: 25]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '74', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-18', '75', '4018', '1', '20471', '141', '74', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-18', '75', '102214', '1', '100', '0', '63745', '0');
--
-- 1.25 Record with dia 226445 doesnt more to condition_occurrence [Test ID: 26]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '77', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-21', '78', '4018', '1', '20471', '141', '77', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-21', '78', '226445', '1', '100', '0', '63745', '0');
--
-- 1.26 Record with dia 102230 doesnt more to condition_occurrence [Test ID: 27]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '80', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-24', '81', '4018', '1', '20471', '141', '80', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-24', '81', '102230', '1', '100', '0', '63745', '0');
--
-- 1.27 Record with dia 886 doesnt more to condition_occurrence [Test ID: 28]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '83', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-27', '84', '4018', '1', '20471', '141', '83', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-27', '84', '886', '1', '100', '0', '63745', '0');
--
-- 1.28 Record with dia 228298 doesnt more to condition_occurrence [Test ID: 29]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '86', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-03-30', '87', '4018', '1', '20471', '141', '86', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-03-30', '87', '228298', '1', '100', '0', '63745', '0');
--
-- 1.29 Record with dia 225864 doesnt more to condition_occurrence [Test ID: 30]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '89', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-02', '90', '4018', '1', '20471', '141', '89', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-02', '90', '225864', '1', '100', '0', '63745', '0');
--
-- 1.30 Record with dia 102226 doesnt more to condition_occurrence [Test ID: 31]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '92', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-05', '93', '4018', '1', '20471', '141', '92', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-05', '93', '102226', '1', '100', '0', '63745', '0');
--
-- 1.31 Record with dia 27917 doesnt more to condition_occurrence [Test ID: 32]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '95', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-08', '96', '4018', '1', '20471', '141', '95', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-08', '96', '27917', '1', '100', '0', '63745', '0');
--
-- 1.32 Record with dia 233651 doesnt more to condition_occurrence [Test ID: 33]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '98', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-11', '99', '4018', '1', '20471', '141', '98', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-11', '99', '233651', '1', '100', '0', '63745', '0');
--
-- 1.33 Record with dia 369218 doesnt more to condition_occurrence [Test ID: 34]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '101', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-14', '102', '4018', '1', '20471', '141', '101', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-14', '102', '369218', '1', '100', '0', '63745', '0');
--
-- 1.34 Record with dia 369203 doesnt more to condition_occurrence [Test ID: 35]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '104', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-17', '105', '4018', '1', '20471', '141', '104', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-17', '105', '369203', '1', '100', '0', '63745', '0');
--
-- 1.35 Record with dia 45049 doesnt more to condition_occurrence [Test ID: 36]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '107', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-20', '108', '4018', '1', '20471', '141', '107', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-20', '108', '45049', '1', '100', '0', '63745', '0');
--
-- 1.36 Record with dia 102248 doesnt more to condition_occurrence [Test ID: 37]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '110', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-23', '111', '4018', '1', '20471', '141', '110', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-04-23', '111', '102248', '1', '100', '0', '63745', '0');
--
-- 1.37 basic prescription ICD10 to condition_occurrence test: 0F3320 [Test ID: 38]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '113', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-26', '114', '4018', '1', '20471', '141', '113', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-04-26', '114', '88962', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.38 basic prescription ICD10 to condition_occurrence test: 0K2910 [Test ID: 39]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '116', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-04-29', '117', '4018', '1', '20471', '141', '116', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-04-29', '117', '372741', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.39 basic prescription ICD10 to condition_occurrence test: 0L2900 [Test ID: 40]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '119', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-02', '120', '4018', '1', '20471', '141', '119', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-02', '120', '9734', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.40 basic prescription ICD10 to condition_occurrence test: 0O0840 [Test ID: 41]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '122', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-05', '123', '4018', '1', '20471', '141', '122', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-05', '123', '270206', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.41 basic prescription SNOMED to condition_occurrence test [Test ID: 42]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '125', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-08', '126', '4018', '1', '20471', '141', '125', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-08', '126', '26444', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.42 8532-specific prescription SNOMED to condition_occurrence test: 6738008 [Test ID: 43]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '128', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-11', '129', '4018', '1', '20471', '141', '128', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-11', '129', '11414', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.43 8507-specific prescription SNOMED to condition_occurrence test: 2904007 [Test ID: 44]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '1', '131', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-14', '132', '4018', '1', '20471', '141', '131', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-14', '132', '10708', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.44 gender-specific diagnostic_contact SNOMED record doesnt match patient gender, no condition_occurrence record [Test ID: 45]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '134', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-17', '135', '4018', '1', '20471', '141', '134', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-17', '135', '11414', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.45 basic prescription condition_occurrence record with provider_id, condition_type_concept_id [Test ID: 46]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '137', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('138', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-21', '139', '4018', '1', '20471', '138', '137', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-21', '139', '117164', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.46 prescription record doesnt map to ICD10/SNOMED [Test ID: 47]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '141', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-24', '142', '4018', '1', '20471', '141', '141', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-24', '142', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.47 2 prescription dia_ids map to one  ICD10, keep 1 condition_occurrence record [Test ID: 48]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '144', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-27', '145', '4018', '1', '20471', '141', '144', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-27', '145', '30772', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-27', '145', '9754', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.48 Record with dia 102268doesnt more to condition_occurrence [Test ID: 49]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '147', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-05-30', '148', '4018', '1', '20471', '141', '147', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-05-30', '148', '102268', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.49 Record with dia 251220doesnt more to condition_occurrence [Test ID: 50]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '150', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-02', '151', '4018', '1', '20471', '141', '150', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-02', '151', '251220', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.50 Record with dia 134016doesnt more to condition_occurrence [Test ID: 51]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '153', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-05', '154', '4018', '1', '20471', '141', '153', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-05', '154', '134016', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.51 Record with dia 3357doesnt more to condition_occurrence [Test ID: 52]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '156', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-08', '157', '4018', '1', '20471', '141', '156', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-08', '157', '3357', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.52 Record with dia 4096doesnt more to condition_occurrence [Test ID: 53]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '159', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-11', '160', '4018', '1', '20471', '141', '159', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-11', '160', '4096', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.53 Record with dia 102340doesnt more to condition_occurrence [Test ID: 54]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '162', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-14', '163', '4018', '1', '20471', '141', '162', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-14', '163', '102340', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.54 Record with dia 225898doesnt more to condition_occurrence [Test ID: 55]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '165', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-17', '166', '4018', '1', '20471', '141', '165', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-17', '166', '225898', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.55 Record with dia 95314doesnt more to condition_occurrence [Test ID: 56]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '168', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-20', '169', '4018', '1', '20471', '141', '168', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-20', '169', '95314', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.56 Record with dia 740076doesnt more to condition_occurrence [Test ID: 57]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '171', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-23', '172', '4018', '1', '20471', '141', '171', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-23', '172', '740076', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.57 Record with dia 102220doesnt more to condition_occurrence [Test ID: 58]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '174', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-26', '175', '4018', '1', '20471', '141', '174', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-26', '175', '102220', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.58 Record with dia 95313doesnt more to condition_occurrence [Test ID: 59]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '177', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-06-29', '178', '4018', '1', '20471', '141', '177', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-06-29', '178', '95313', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.59 Record with dia 102228doesnt more to condition_occurrence [Test ID: 60]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '180', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-02', '181', '4018', '1', '20471', '141', '180', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-02', '181', '102228', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.60 Record with dia 228447doesnt more to condition_occurrence [Test ID: 61]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '183', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-05', '184', '4018', '1', '20471', '141', '183', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-05', '184', '228447', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.61 Record with dia 102214doesnt more to condition_occurrence [Test ID: 62]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '186', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-08', '187', '4018', '1', '20471', '141', '186', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-08', '187', '102214', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.62 Record with dia 226445doesnt more to condition_occurrence [Test ID: 63]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '189', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-11', '190', '4018', '1', '20471', '141', '189', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-11', '190', '226445', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.63 Record with dia 102230doesnt more to condition_occurrence [Test ID: 64]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '192', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-14', '193', '4018', '1', '20471', '141', '192', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-14', '193', '102230', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.64 Record with dia 886doesnt more to condition_occurrence [Test ID: 65]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '195', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-17', '196', '4018', '1', '20471', '141', '195', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-17', '196', '886', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.65 Record with dia 228298doesnt more to condition_occurrence [Test ID: 66]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '198', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-20', '199', '4018', '1', '20471', '141', '198', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-20', '199', '228298', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.66 Record with dia 225864doesnt more to condition_occurrence [Test ID: 67]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '201', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-23', '202', '4018', '1', '20471', '141', '201', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-23', '202', '225864', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.67 Record with dia 102226doesnt more to condition_occurrence [Test ID: 68]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '204', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-26', '205', '4018', '1', '20471', '141', '204', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-26', '205', '102226', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.68 Record with dia 27917doesnt more to condition_occurrence [Test ID: 69]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '207', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-07-29', '208', '4018', '1', '20471', '141', '207', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-07-29', '208', '27917', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.69 Record with dia 233651doesnt more to condition_occurrence [Test ID: 70]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '210', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-01', '211', '4018', '1', '20471', '141', '210', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-08-01', '211', '233651', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.70 Record with dia 369218doesnt more to condition_occurrence [Test ID: 71]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '213', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-04', '214', '4018', '1', '20471', '141', '213', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-08-04', '214', '369218', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.71 Record with dia 369203doesnt more to condition_occurrence [Test ID: 72]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '216', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-07', '217', '4018', '1', '20471', '141', '216', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-08-07', '217', '369203', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.72 Record with dia 45049doesnt more to condition_occurrence [Test ID: 73]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '219', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-10', '220', '4018', '1', '20471', '141', '219', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-08-10', '220', '45049', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.73 Record with dia 102248doesnt more to condition_occurrence [Test ID: 74]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '222', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-13', '223', '4018', '1', '20471', '141', '222', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-08-13', '223', '102248', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 1.74 Smoker condition from biometic: is_smoker=0, dalyly_cigaret_number=5 [Test ID: 75]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '225', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-16', '226', '4018', '1', '20471', '141', '225', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, con_date, con_id, dayly_cigaret_number, is_smoker, min_bp, tra_id, version) VALUES ('0', '2010-08-16', '226', '5', '0', '80', '52164', '0');
--
-- 1.75 Smoker condition from biometic: is_smoker=1, dalyly_cigaret_number=0 [Test ID: 76]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '228', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-19', '229', '4018', '1', '20471', '141', '228', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, con_date, con_id, dayly_cigaret_number, is_smoker, min_bp, tra_id, version) VALUES ('0', '2010-08-19', '229', '0', '1', '80', '52164', '0');
--
-- 1.76 No smoking condition_occurrence record created [Test ID: 77]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '231', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-22', '232', '4018', '1', '20471', '141', '231', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, con_date, con_id, dayly_cigaret_number, is_smoker, min_bp, tra_id, version) VALUES ('0', '2010-08-22', '232', '0', '0', '80', '52164', '0');
--
-- 1.77 Condition_occurrence from allergy, allergy start date used, alg_id=17900 [Test ID: 78]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '234', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-26', '235', '4018', '1', '20471', '141', '234', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('17900', '9999-12-31', '2772693', '2010-08-25', '2010-08-26', '-1', '234', '-1', '37699', '0');
--
-- 1.78 Condition_occurrence from allergy, allergy start date used, alg_id=18019 [Test ID: 79]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '238', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-08-30', '239', '4018', '1', '20471', '141', '238', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18019', '9999-12-31', '2772693', '2010-08-29', '2010-08-30', '-1', '238', '-1', '37699', '0');
--
-- 1.79 Condition_occurrence from allergy, allergy start date used, alg_id=14897 [Test ID: 80]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '242', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-03', '243', '4018', '1', '20471', '141', '242', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('14897', '9999-12-31', '2772693', '2010-09-02', '2010-09-03', '-1', '242', '-1', '37699', '0');
--
-- 1.80 Condition_occurrence from allergy, allergy start date used, alg_id=18437 [Test ID: 81]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '246', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-07', '247', '4018', '1', '20471', '141', '246', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18437', '9999-12-31', '2772693', '2010-09-06', '2010-09-07', '-1', '246', '-1', '37699', '0');
--
-- 1.81 Condition_occurrence from allergy, allergy start date used, alg_id=265449 [Test ID: 82]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '250', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-11', '251', '4018', '1', '20471', '141', '250', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('265449', '9999-12-31', '2772693', '2010-09-10', '2010-09-11', '-1', '250', '-1', '37699', '0');
--
-- 1.82 Condition_occurrence from allergy, allergy start date used, alg_id=265495 [Test ID: 83]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '254', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-15', '255', '4018', '1', '20471', '141', '254', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('265495', '9999-12-31', '2772693', '2010-09-14', '2010-09-15', '-1', '254', '-1', '37699', '0');
--
-- 1.83 Condition_occurrence from allergy, allergy start date used, alg_id=16602 [Test ID: 84]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '258', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-19', '259', '4018', '1', '20471', '141', '258', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('16602', '9999-12-31', '2772693', '2010-09-18', '2010-09-19', '-1', '258', '-1', '37699', '0');
--
-- 1.84 Condition_occurrence from allergy, allergy start date used, alg_id=267159 [Test ID: 85]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '262', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-23', '263', '4018', '1', '20471', '141', '262', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('267159', '9999-12-31', '2772693', '2010-09-22', '2010-09-23', '-1', '262', '-1', '37699', '0');
--
-- 1.85 Condition_occurrence from allergy, allergy start date used, alg_id=267166 [Test ID: 86]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '266', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-27', '267', '4018', '1', '20471', '141', '266', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('267166', '9999-12-31', '2772693', '2010-09-26', '2010-09-27', '-1', '266', '-1', '37699', '0');
--
-- 1.86 Condition_occurrence from allergy, unmapped alg_id, null allergy start date [Test ID: 87]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '270', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-09-30', '271', '4018', '1', '20471', '141', '270', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('999999', '9999-12-31', '2772693', '2010-09-30', '-1', '270', '-1', '37699', '0');

-- 2. Death
--
-- 2.0 Death list code 3017 from patient_medical_history [Test ID: 88]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '273', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3017', '2010-10-02', '2010-10-02', '273', '27881', '0');
--
-- 2.1 Death list code 3027 from patient_medical_history [Test ID: 89]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '275', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3027', '2010-10-04', '2010-10-04', '275', '27881', '0');
--
-- 2.2 Death list code 3032 from patient_medical_history [Test ID: 90]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '277', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3032', '2010-10-06', '2010-10-06', '277', '27881', '0');
--
-- 2.3 Death list code 3035 from patient_medical_history [Test ID: 91]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '279', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3035', '2010-10-08', '2010-10-08', '279', '27881', '0');
--
-- 2.4 Death list code 10888 from patient_medical_history [Test ID: 92]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '281', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('10888', '2010-10-10', '2010-10-10', '281', '27881', '0');
--
-- 2.5 Death list code 11445 from patient_medical_history [Test ID: 93]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '283', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('11445', '2010-10-12', '2010-10-12', '283', '27881', '0');
--
-- 2.6 Death list code 634607 from patient_medical_history [Test ID: 94]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '285', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('634607', '2010-10-14', '2010-10-14', '285', '27881', '0');
--
-- 2.7 Death list code 244264 from patient_medical_history [Test ID: 95]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '287', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('244264', '2010-10-16', '2010-10-16', '287', '27881', '0');
--
-- 2.8 death date from known_since (chosen over input_date) [Test ID: 96]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '289', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3027', '2010-10-19', '2010-10-18', '289', '27881', '0');
--
-- 2.9 Death date from input_date (where known_since is null) [Test ID: 97]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '292', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, pat_id, tra_id, version) VALUES ('3035', '2010-10-21', '292', '27881', '0');
--
-- 2.10 Take minimum death date where multiple death records [Test ID: 98]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '294', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3027', '2010-10-24', '2010-10-23', '294', '27881', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3035', '2010-10-26', '2010-10-25', '294', '27881', '0');
--
-- 2.11 Minimum death date > current date - not dead [Test ID: 99]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '299', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3027', '2012-11-12', '2050-01-01', '299', '27881', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3035', '2012-11-12', '2025-01-01', '299', '27881', '0');
--
-- 2.12 patient with contact record after patient_medical_history death date - not dead [Test ID: 100]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '300', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-10-30', '31380393', '4018', '1', '20471', '141', '300', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3017', '2012-11-12', '2010-10-29', '300', '27881', '0');
--
-- 2.13 patient with test_result record (tst_date) after patient_medical_history death date - not dead [Test ID: 101]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '303', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-11-02', '304', '4018', '1', '20471', '141', '303', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3017', '2012-11-12', '2010-11-03', '303', '27881', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2010-11-02', '304', '0.0', '63745', '2010-11-04', '222512', '281690', '0.0', '0');
--
-- 2.14 patient with immunization record after patient_medical_history death date - not dead [Test ID: 102]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '308', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('3027', '2012-11-12', '2010-11-06', '308', '27881', '0');
INSERT INTO immunization (first_time, imm_id, imt_id, input_date, pat_id, tra_id, vaccination_date, version) VALUES ('0', '2351607', '50050', '2010-02-13', '308', '36558', '2010-11-07', '0');
--
-- 2.15 patient with allergy record after patient_medical_history death date - not dead [Test ID: 103]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '311', '24824', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('10888', '2012-11-12', '2010-11-09', '311', '27881', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2010-11-10', '2010-09-11', '-1', '311', '-1', '37699', '0');
--
-- 2.16 Death list code 3017 from diagnostic_contact [Test ID: 104]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '314', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-11-13', '315', '4018', '1', '20471', '141', '314', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-11-13', '315', '3017', '1', '100', '0', '63745', '0');
--
-- 2.17 Death list code 3027 from diagnostic_contact [Test ID: 105]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '317', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-11-16', '318', '4018', '1', '20471', '141', '317', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-11-16', '318', '3027', '1', '100', '0', '63745', '0');
--
-- 2.18 Death list code 3032 from diagnostic_contact [Test ID: 106]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '320', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-11-19', '321', '4018', '1', '20471', '141', '320', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-11-19', '321', '3032', '1', '100', '0', '63745', '0');
--
-- 2.19 Death list code 3035 from diagnostic_contact [Test ID: 107]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '323', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-11-22', '324', '4018', '1', '20471', '141', '323', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-11-22', '324', '3035', '1', '100', '0', '63745', '0');
--
-- 2.20 Death list code 10888 from diagnostic_contact [Test ID: 108]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '326', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-11-25', '327', '4018', '1', '20471', '141', '326', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-11-25', '327', '10888', '1', '100', '0', '63745', '0');
--
-- 2.21 Death list code 11445 from diagnostic_contact [Test ID: 109]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '329', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-11-28', '330', '4018', '1', '20471', '141', '329', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-11-28', '330', '11445', '1', '100', '0', '63745', '0');
--
-- 2.22 Death list code 634607 from diagnostic_contact [Test ID: 110]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '332', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-01', '333', '4018', '1', '20471', '141', '332', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-12-01', '333', '634607', '1', '100', '0', '63745', '0');
--
-- 2.23 Death list code 244264 from diagnostic_contact [Test ID: 111]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '335', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-04', '336', '4018', '1', '20471', '141', '335', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-12-04', '336', '244264', '1', '100', '0', '63745', '0');
--
-- 2.24 patient with prescription record after diagnostic_contact death date - not dead [Test ID: 112]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '338', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-08', '339', '4018', '1', '20471', '141', '338', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-12-08', '336', '3027', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-09', '340', '4018', '1', '20471', '141', '338', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-12-09', '340', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.25 patient with test_result record after diagnostic_contact death date - not dead [Test ID: 113]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '343', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-13', '344', '4018', '1', '20471', '141', '343', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-12-13', '336', '3027', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-14', '345', '4018', '1', '20471', '141', '343', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2010-12-14', '345', '0.0', '63745', '2010-12-14', '222512', '281690', '0.0', '0');
--
-- 2.26 patient with patient_medical_hist record after diagnostic_contact death date - not dead [Test ID: 114]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '348', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-17', '349', '4018', '1', '20471', '141', '348', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-12-17', '349', '3027', '1', '100', '0', '63745', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('13092', '2012-11-12', '2010-12-18', '348', '27881', '0');
--
-- 2.27 patient with immunization record after diagnostic_contact death date - not dead [Test ID: 115]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '352', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-21', '353', '4018', '1', '20471', '141', '352', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-12-21', '353', '3027', '1', '100', '0', '63745', '0');
INSERT INTO immunization (first_time, imm_id, imt_id, input_date, pat_id, tra_id, vaccination_date, version) VALUES ('0', '2351607', '50050', '2010-02-13', '352', '36558', '2010-12-22', '0');
--
-- 2.28 patient with allergy record after diagnostic_contact death date - not dead [Test ID: 116]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '356', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-25', '357', '4018', '1', '20471', '141', '356', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-12-25', '357', '3027', '1', '100', '0', '63745', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2010-12-26', '2010-09-11', '-1', '356', '-1', '37699', '0');
--
-- 2.29 Death list code 3017 from prescription, drug record to drug_exposure [Test ID: 117]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '360', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-12-29', '361', '4018', '1', '20471', '141', '360', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2010-12-29', '361', '3017', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.30 Death list code 3027 from prescription, drug record to drug_exposure [Test ID: 118]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '363', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-01', '364', '4018', '1', '20471', '141', '363', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-01', '364', '3027', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.31 Death list code 3032 from prescription, drug record to drug_exposure [Test ID: 119]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '366', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-04', '367', '4018', '1', '20471', '141', '366', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-04', '367', '3032', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.32 Death list code 3035 from prescription, drug record to drug_exposure [Test ID: 120]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '369', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-07', '370', '4018', '1', '20471', '141', '369', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-07', '370', '3035', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.33 Death list code 10888 from prescription, drug record to drug_exposure [Test ID: 121]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '372', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-10', '373', '4018', '1', '20471', '141', '372', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-10', '373', '10888', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.34 Death list code 11445 from prescription, drug record to drug_exposure [Test ID: 122]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '375', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-13', '376', '4018', '1', '20471', '141', '375', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-13', '376', '11445', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.35 Death list code 634607 from prescription, drug record to drug_exposure [Test ID: 123]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '378', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-16', '379', '4018', '1', '20471', '141', '378', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-16', '379', '634607', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 2.36 Death list code 244264 from prescription, drug record to drug_exposure [Test ID: 124]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '381', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-19', '382', '4018', '1', '20471', '141', '381', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-19', '382', '244264', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');

-- 3. Device Exposure
--
-- 3.0 basic prescription device mapping and start date587944 [Test ID: 125]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '384', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-22', '385', '4018', '1', '20471', '141', '384', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-22', '385', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '587944', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 3.1 basic prescription device mapping and start date20229 [Test ID: 126]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '387', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-25', '388', '4018', '1', '20471', '141', '387', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-25', '388', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '20229', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 3.2 basic prescription device mapping and start date10403 [Test ID: 127]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '390', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-28', '391', '4018', '1', '20471', '141', '390', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-28', '391', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '10403', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 3.3 basic prescription device mapping and start date591148 [Test ID: 128]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '393', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-01-31', '394', '4018', '1', '20471', '141', '393', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-01-31', '394', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '591148', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 3.4 basic prescription device mapping and start date587656 [Test ID: 129]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '396', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-03', '397', '4018', '1', '20471', '141', '396', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-03', '397', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '587656', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 3.5 basic prescription device mapping and start date588117 [Test ID: 130]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '399', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-06', '400', '4018', '1', '20471', '141', '399', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-06', '400', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588117', '100', '17574271', '0', '5001', '37749', '30', '0');

-- 4. Drug Exposure
--
-- 4.0 basic prescription drug mapping and start date, prd_id:603082 [Test ID: 131]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '402', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-09', '403', '4018', '1', '20471', '141', '402', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-09', '403', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '603082', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.1 basic prescription drug mapping and start date, prd_id:603035 [Test ID: 132]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '405', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-12', '406', '4018', '1', '20471', '141', '405', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-12', '406', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '603035', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.2 basic prescription drug mapping and start date, prd_id:603036 [Test ID: 133]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '408', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-15', '409', '4018', '1', '20471', '141', '408', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-15', '409', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '603036', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.3 basic prescription drug mapping and start date, prd_id:22909 [Test ID: 134]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '411', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-18', '412', '4018', '1', '20471', '141', '411', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-18', '412', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '22909', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.4 basic prescription drug mapping and start date, prd_id:15096 [Test ID: 135]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '414', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-21', '415', '4018', '1', '20471', '141', '414', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-21', '415', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15096', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.5 basic prescription drug mapping and start date, prd_id:15095 [Test ID: 136]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '417', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-24', '418', '4018', '1', '20471', '141', '417', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-24', '418', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '15095', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.6 basic prescription drug mapping and start date, prd_id:2746 [Test ID: 137]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '420', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-02-27', '421', '4018', '1', '20471', '141', '420', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-02-27', '421', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '2746', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.7 basic prescription drug mapping and start date, prd_id:2747 [Test ID: 138]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '423', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-03-02', '424', '4018', '1', '20471', '141', '423', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-03-02', '424', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '2747', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.8 basic prescription drug mapping and start date, prd_id:16209 [Test ID: 139]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '426', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-03-05', '427', '4018', '1', '20471', '141', '426', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-03-05', '427', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '16209', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.9 basic prescription drug mapping and start date, prd_id:603006 [Test ID: 140]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '429', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-03-08', '430', '4018', '1', '20471', '141', '429', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-03-08', '430', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '603006', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.10 basic prescription drug mapping and start date, prd_id:21673 [Test ID: 141]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '432', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-03-11', '433', '4018', '1', '20471', '141', '432', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-03-11', '433', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '21673', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.11 basic prescription drug mapping and start date, prd_id:21674 [Test ID: 142]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '435', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-03-14', '436', '4018', '1', '20471', '141', '435', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-03-14', '436', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '21674', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.12 basic prescription drug mapping and start date, prd_id:21672 [Test ID: 143]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '438', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-03-17', '439', '4018', '1', '20471', '141', '438', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-03-17', '439', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '21672', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.13 basic prescription drug mapping and start date, prd_id:25223 [Test ID: 144]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '441', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-03-20', '442', '4018', '1', '20471', '141', '441', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-03-20', '442', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '25223', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.14 correct prescription renewal to refills [Test ID: 145]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '444', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2013-03-25', '445', '4018', '1', '20471', '141', '444', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2013-03-25', '445', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '5', '5001', '37749', '30', '0');
--
-- 4.15 null prescription renewal to 0 refills [Test ID: 146]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '446', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2013-03-25', '447', '4018', '1', '20471', '141', '446', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2013-03-25', '447', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '5001', '37749', '30', '0');
--
-- 4.16 correct quantity record [Test ID: 147]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '448', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2013-03-25', '449', '4018', '1', '20471', '141', '448', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2013-03-25', '449', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '90', '0');
--
-- 4.17 min_duration_in_days to days_supply round up [Test ID: 148]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '450', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2013-03-25', '451', '4018', '1', '20471', '141', '450', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2013-03-25', '451', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '5.01', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.18 sig string, effective_drug_dose test [Test ID: 149]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '452', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2013-03-25', '453', '4018', '1', '20471', '141', '452', '8127', '36977', '0');
INSERT INTO prescription (additional_info, con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('1 tablet swallowed whole prn for migraine. Repeat if needed. Max dose 6 tablets/24hrs.', '2013-03-25', '453', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '7.5', '0', '0', '30', '0', '0', '0', '4', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.19 route_concept_id test [Test ID: 150]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '454', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2013-03-25', '455', '4018', '1', '20471', '141', '454', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2013-03-25', '455', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '3882', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.20 correct provider_id in drug_exposure from contact table [Test ID: 151]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '456', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('458', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2013-03-25', '457', '4018', '1', '20471', '458', '456', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2013-03-25', '457', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 4.21 immunization mapping no age, date from vaccination_date [Test ID: 152]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '459', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-04-07', '460', '4018', '1', '20471', '141', '459', '8127', '36977', '0');
INSERT INTO immunization (first_time, imm_id, imt_id, input_date, pat_id, tra_id, vaccination_date, version) VALUES ('0', '2351607', '50041', '2011-04-08', '459', '36558', '2011-04-07', '0');
--
-- 4.22 immunization mapping adult, start date from vaccination_date [Test ID: 153]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1980', '2', '2', '463', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-01', '464', '4018', '1', '20471', '141', '463', '8127', '36977', '0');
INSERT INTO immunization (first_time, imm_id, imt_id, input_date, pat_id, tra_id, vaccination_date, version) VALUES ('0', '2351607', '49984', '2010-01-01', '463', '36558', '2010-01-01', '0');
--
-- 4.23 immunization mapping child, start date from vaccination_date [Test ID: 154]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '2008', '2', '2', '465', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-01', '466', '4018', '1', '20471', '141', '465', '8127', '36977', '0');
INSERT INTO immunization (first_time, imm_id, imt_id, input_date, pat_id, tra_id, vaccination_date, version) VALUES ('0', '2351607', '49984', '2010-01-01', '465', '36558', '2010-01-01', '0');

-- 5. Location
--
-- 5.0 Care_site and location test from state: NSW [Test ID: 155]
--
INSERT INTO practice (pra_id, state, postcode) VALUES ('22126', 'NSW', '2000-2009');
--
-- 5.1 Care_site and location test from state: QLD [Test ID: 156]
--
INSERT INTO practice (pra_id, state, postcode) VALUES ('1130', 'QLD', '4120-4129');
--
-- 5.2 Care_site and location test from state: SA [Test ID: 157]
--
INSERT INTO practice (pra_id, state, postcode) VALUES ('8', 'SA', '5020-5029');
--
-- 5.3 Care_site and location test from state: VIC [Test ID: 158]
--
INSERT INTO practice (pra_id, state, postcode) VALUES ('10127', 'VIC', '3020-3029');
--
-- 5.4 Care_site and location test from state: WA [Test ID: 159]
--
INSERT INTO practice (pra_id, state, postcode) VALUES ('108', 'WA', '6050-6059');

-- 6. Measurement
--
-- 6.0 basic diagnositic_contact ICD10 to measurement test: 0R7300 [Test ID: 160]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '467', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-04-15', '468', '4018', '1', '20471', '141', '467', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-04-15', '468', '155751', '1', '100', '0', '63745', '0');
--
-- 6.1 basic diagnositic_contact ICD10 to measurement test: 0Z3200 [Test ID: 161]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '470', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-04-18', '471', '4018', '1', '20471', '141', '470', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-04-18', '471', '9422', '1', '100', '0', '63745', '0');
--
-- 6.2 basic diagnositic_contact ICD10 to measurement test: 0R9450 [Test ID: 162]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '473', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-04-21', '474', '4018', '1', '20471', '141', '473', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-04-21', '474', '90', '1', '100', '0', '63745', '0');
--
-- 6.3 basic diagnositic_contact ICD10 to measurement test: 0R1950 [Test ID: 163]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '476', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-04-24', '477', '4018', '1', '20471', '141', '476', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-04-24', '477', '2180', '1', '100', '0', '63745', '0');
--
-- 6.4 2 diagnostic_contact dia_ids map to one  ICD10, keep 1 measurement record [Test ID: 164]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '479', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-04-27', '480', '4018', '1', '20471', '141', '479', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-04-27', '480', '153998', '1', '100', '0', '63745', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-04-27', '480', '1614', '1', '100', '0', '63745', '0');
--
-- 6.5 basic diagnostic_contact measurement record with provider_id, measurement_type_concept_id [Test ID: 165]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '482', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('483', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-01', '484', '4018', '1', '20471', '483', '482', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-05-01', '484', '244100', '1', '100', '0', '63745', '0');
--
-- 6.6 basic prescription ICD10 to measurement test: 0R8210 [Test ID: 166]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '486', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-04', '487', '4018', '1', '20471', '141', '486', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-05-04', '487', '7870', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 6.7 basic prescription ICD10 to measurement test: 0R9450 [Test ID: 167]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '489', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-07', '490', '4018', '1', '20471', '141', '489', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-05-07', '490', '17712', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 6.8 basic prescription ICD10 to measurement test: 0R7300 [Test ID: 168]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '492', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-10', '493', '4018', '1', '20471', '141', '492', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-05-10', '493', '155690', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 6.9 basic prescription ICD10 to measurement test: 0R3100 [Test ID: 169]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '495', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-13', '496', '4018', '1', '20471', '141', '495', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-05-13', '496', '143323', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 6.10 2 prescription dia_ids map to one  ICD10, keep 1 measurement record [Test ID: 170]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '498', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-16', '499', '4018', '1', '20471', '141', '498', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-05-16', '499', '4806', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-05-16', '499', '351267', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 6.11 basic prescription measurement record with provider_id, measurement_type_concept_id [Test ID: 171]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '501', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('502', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-20', '503', '4018', '1', '20471', '502', '501', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-05-20', '503', '426', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 6.12 measurement record from biometric: Pulse [Test ID: 172]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '505', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-23', '506', '4018', '1', '20471', '141', '505', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '0', '2011-05-23', '506', '0', '0', '0', '0', '0', '1', '52164', '0', '0', '0');
--
-- 6.13 measurement record from biometric: Max_bp [Test ID: 173]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '508', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-26', '509', '4018', '1', '20471', '141', '508', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '0', '2011-05-26', '509', '0', '0', '0', '1', '0', '0', '52164', '0', '0', '0');
--
-- 6.14 measurement record from biometric: Min_bp [Test ID: 174]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '511', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-05-29', '512', '4018', '1', '20471', '141', '511', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '0', '2011-05-29', '512', '0', '0', '0', '0', '1', '0', '52164', '0', '0', '0');
--
-- 6.15 measurement record from biometric: Dayly_cigaret_number [Test ID: 175]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '514', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-01', '515', '4018', '1', '20471', '141', '514', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '0', '2011-06-01', '515', '1', '0', '0', '0', '0', '0', '52164', '0', '0', '0');
--
-- 6.16 measurement record from biometric: Body_mass_index [Test ID: 176]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '517', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-04', '518', '4018', '1', '20471', '141', '517', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '1', '2011-06-04', '518', '0', '0', '0', '0', '0', '0', '52164', '0', '0', '0');
--
-- 6.17 measurement record from biometric: Height [Test ID: 177]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '520', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-07', '521', '4018', '1', '20471', '141', '520', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '0', '2011-06-07', '521', '0', '1', '0', '0', '0', '0', '52164', '0', '0', '0');
--
-- 6.18 measurement record from biometric: Waist_measurement [Test ID: 178]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '523', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-10', '524', '4018', '1', '20471', '141', '523', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '0', '2011-06-10', '524', '0', '0', '0', '0', '0', '0', '52164', '0', '1', '0');
--
-- 6.19 measurement record from biometric: Weight [Test ID: 179]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '526', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-13', '527', '4018', '1', '20471', '141', '526', '8127', '36977', '0');
INSERT INTO biometric (alcohol_drinker, body_mass_index, con_date, con_id, dayly_cigaret_number, height, is_smoker, max_bp, min_bp, pulse, tra_id, version, waist_measurement, weight) VALUES ('0', '0', '2011-06-13', '527', '0', '0', '0', '0', '0', '0', '52164', '0', '0', '1');
--
-- 6.20 basic measurement record from test_result with date, tst_id: 221266 [Test ID: 180]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '529', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-16', '530', '4018', '1', '20471', '141', '529', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2011-06-16', '530', '0.0', '63745', '2011-06-16', '221266', '281690', '0.0', '0');
--
-- 6.21 basic measurement record from test_result with date, tst_id: 220751 [Test ID: 181]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '532', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-19', '533', '4018', '1', '20471', '141', '532', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2011-06-19', '533', '0.0', '63745', '2011-06-19', '220751', '281690', '0.0', '0');
--
-- 6.22 basic measurement record from test_result with date, tst_id: 220282 [Test ID: 182]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '535', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-22', '536', '4018', '1', '20471', '141', '535', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2011-06-22', '536', '0.0', '63745', '2011-06-22', '220282', '281690', '0.0', '0');
--
-- 6.23 basic measurement record from test_result with date, tst_id: 221782 [Test ID: 183]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '538', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-25', '539', '4018', '1', '20471', '141', '538', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2011-06-25', '539', '0.0', '63745', '2011-06-25', '221782', '281690', '0.0', '0');
--
-- 6.24 tst_id with no corresponding LOINC code, maps to 0 [Test ID: 184]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '541', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-06-28', '542', '4018', '1', '20471', '141', '541', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2011-06-28', '542', '0.0', '63745', '2011-06-28', '99999', '281690', '0.0', '0');
--
-- 6.25 measurement value test, no conversion factor [Test ID: 185]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '544', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-01', '545', '4018', '1', '20471', '141', '544', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-01', '545', '0.0', '63745', '2011-07-01', '222281', '20670', '281690', '32.1', '0');
--
-- 6.26 measurement value test with conversion factor and unmapped unit [Test ID: 186]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '547', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-04', '548', '4018', '1', '20471', '141', '547', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-04', '548', '0.0', '63745', '2011-07-04', '7244', '20672', '282190', '3.4', '0');
--
-- 6.27 measurement record from test_result, unit test: /ml [Test ID: 187]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '550', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-07', '551', '4018', '1', '20471', '141', '550', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-07', '551', '0.0', '63745', '2011-07-07', '222512', '281510', '281510', '0.0', '0');
--
-- 6.28 measurement record from test_result, unit test: /ul [Test ID: 188]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '553', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-10', '554', '4018', '1', '20471', '141', '553', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-10', '554', '0.0', '63745', '2011-07-10', '222512', '281932', '281932', '0.0', '0');
--
-- 6.29 measurement record from test_result, unit test: C [Test ID: 189]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '556', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-13', '557', '4018', '1', '20471', '141', '556', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-13', '557', '0.0', '63745', '2011-07-13', '222512', '281562', '281562', '0.0', '0');
--
-- 6.30 measurement record from test_result, unit test: fl [Test ID: 190]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '559', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-16', '560', '4018', '1', '20471', '141', '559', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-16', '560', '0.0', '63745', '2011-07-16', '222512', '281592', '281592', '0.0', '0');
--
-- 6.31 measurement record from test_result, unit test: fmol/l [Test ID: 191]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '562', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-19', '563', '4018', '1', '20471', '141', '562', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-19', '563', '0.0', '63745', '2011-07-19', '222512', '282082', '282082', '0.0', '0');
--
-- 6.32 measurement record from test_result, unit test: g/dl [Test ID: 192]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '565', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-22', '566', '4018', '1', '20471', '141', '565', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-22', '566', '0.0', '63745', '2011-07-22', '222512', '281600', '281600', '0.0', '0');
--
-- 6.33 measurement record from test_result, unit test: g/l [Test ID: 193]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '568', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-25', '569', '4018', '1', '20471', '141', '568', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-25', '569', '0.0', '63745', '2011-07-25', '222512', '281602', '281602', '0.0', '0');
--
-- 6.34 measurement record from test_result, unit test: g/ml [Test ID: 194]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '571', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-28', '572', '4018', '1', '20471', '141', '571', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-28', '572', '0.0', '63745', '2011-07-28', '222512', '282096', '282096', '0.0', '0');
--
-- 6.35 measurement record from test_result, unit test: l/l [Test ID: 195]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '574', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-07-31', '575', '4018', '1', '20471', '141', '574', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-07-31', '575', '0.0', '63745', '2011-07-31', '222512', '282136', '282136', '0.0', '0');
--
-- 6.36 measurement record from test_result, unit test: mg/dl [Test ID: 196]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '577', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-03', '578', '4018', '1', '20471', '141', '577', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-03', '578', '0.0', '63745', '2011-08-03', '222512', '281654', '281654', '0.0', '0');
--
-- 6.37 measurement record from test_result, unit test: mg/l [Test ID: 197]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '580', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-06', '581', '4018', '1', '20471', '141', '580', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-06', '581', '0.0', '63745', '2011-08-06', '222512', '281659', '281659', '0.0', '0');
--
-- 6.38 measurement record from test_result, unit test: ml [Test ID: 198]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '583', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-09', '584', '4018', '1', '20471', '141', '583', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-09', '584', '0.0', '63745', '2011-08-09', '222512', '281671', '281671', '0.0', '0');
--
-- 6.39 measurement record from test_result, unit test: ml/min [Test ID: 199]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '586', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-12', '587', '4018', '1', '20471', '141', '586', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-12', '587', '0.0', '63745', '2011-08-12', '222512', '281676', '281676', '0.0', '0');
--
-- 6.40 measurement record from test_result, unit test: mmol/l [Test ID: 200]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '589', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-15', '590', '4018', '1', '20471', '141', '589', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-15', '590', '0.0', '63745', '2011-08-15', '222512', '281690', '281690', '0.0', '0');
--
-- 6.41 measurement record from test_result, unit test: mol/l [Test ID: 201]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '592', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-18', '593', '4018', '1', '20471', '141', '592', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-18', '593', '0.0', '63745', '2011-08-18', '222512', '281695', '281695', '0.0', '0');
--
-- 6.42 measurement record from test_result, unit test: ng/l [Test ID: 202]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '595', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-21', '596', '4018', '1', '20471', '141', '595', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-21', '596', '0.0', '63745', '2011-08-21', '222512', '281719', '281719', '0.0', '0');
--
-- 6.43 measurement record from test_result, unit test: ng/ml [Test ID: 203]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '598', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-24', '599', '4018', '1', '20471', '141', '598', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-24', '599', '0.0', '63745', '2011-08-24', '222512', '281721', '281721', '0.0', '0');
--
-- 6.44 measurement record from test_result, unit test: nM/l [Test ID: 204]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '601', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-27', '602', '4018', '1', '20471', '141', '601', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-27', '602', '0.0', '63745', '2011-08-27', '222512', '282238', '282238', '0.0', '0');
--
-- 6.45 measurement record from test_result, unit test: nmol/l [Test ID: 205]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '604', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-08-30', '605', '4018', '1', '20471', '141', '604', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-08-30', '605', '0.0', '63745', '2011-08-30', '222512', '281732', '281732', '0.0', '0');
--
-- 6.46 measurement record from test_result, unit test: pg/ml [Test ID: 206]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '607', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-02', '608', '4018', '1', '20471', '141', '607', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-02', '608', '0.0', '63745', '2011-09-02', '222512', '281754', '281754', '0.0', '0');
--
-- 6.47 measurement record from test_result, unit test: pmol/l [Test ID: 207]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '610', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-05', '611', '4018', '1', '20471', '141', '610', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-05', '611', '0.0', '63745', '2011-09-05', '222512', '281758', '281758', '0.0', '0');
--
-- 6.48 measurement record from test_result, unit test: pmol/ml [Test ID: 208]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '613', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-08', '614', '4018', '1', '20471', '141', '613', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-08', '614', '0.0', '63745', '2011-09-08', '222512', '281760', '281760', '0.0', '0');
--
-- 6.49 measurement record from test_result, unit test: U [Test ID: 209]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '616', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-11', '617', '4018', '1', '20471', '141', '616', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-11', '617', '0.0', '63745', '2011-09-11', '222512', '281773', '281773', '0.0', '0');
--
-- 6.50 measurement record from test_result, unit test: ug/dl [Test ID: 210]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '619', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-14', '620', '4018', '1', '20471', '141', '619', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-14', '620', '0.0', '63745', '2011-09-14', '222512', '281793', '281793', '0.0', '0');
--
-- 6.51 measurement record from test_result, unit test: ug/l [Test ID: 211]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '622', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-17', '623', '4018', '1', '20471', '141', '622', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-17', '623', '0.0', '63745', '2011-09-17', '222512', '281796', '281796', '0.0', '0');
--
-- 6.52 measurement record from test_result, unit test: ug/ml [Test ID: 212]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '625', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-20', '626', '4018', '1', '20471', '141', '625', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-20', '626', '0.0', '63745', '2011-09-20', '222512', '281799', '281799', '0.0', '0');
--
-- 6.53 measurement record from test_result, unit test: umol/l [Test ID: 213]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '628', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-23', '629', '4018', '1', '20471', '141', '628', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-23', '629', '0.0', '63745', '2011-09-23', '222512', '281810', '281810', '0.0', '0');
--
-- 6.54 measurement record from test_result where tst_unit_id = 281856, unit test from appendix: 219735 [Test ID: 214]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '631', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-26', '632', '4018', '1', '20471', '141', '631', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-26', '632', '0.0', '63745', '2011-09-26', '219735', '219735', '281856', '0.0', '0');
--
-- 6.55 measurement record from test_result where tst_unit_id = 281856, unit test from appendix: 220187 [Test ID: 215]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '634', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-09-29', '635', '4018', '1', '20471', '141', '634', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-09-29', '635', '0.0', '63745', '2011-09-29', '220187', '220187', '281856', '0.0', '0');
--
-- 6.56 measurement record from test_result where tst_unit_id = 281856, unit test from appendix: 220190 [Test ID: 216]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '637', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-02', '638', '4018', '1', '20471', '141', '637', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-10-02', '638', '0.0', '63745', '2011-10-02', '220190', '220190', '281856', '0.0', '0');
--
-- 6.57 measurement record from test_result where tst_unit_id = 281856, unit test from appendix: 221148 [Test ID: 217]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '640', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-05', '641', '4018', '1', '20471', '141', '640', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-10-05', '641', '0.0', '63745', '2011-10-05', '221148', '221148', '281856', '0.0', '0');
--
-- 6.58 measurement record from test_result where tst_unit_id = 281856, unit test from appendix: 221150 [Test ID: 218]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '643', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-08', '644', '4018', '1', '20471', '141', '643', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-10-08', '644', '0.0', '63745', '2011-10-08', '221150', '221150', '281856', '0.0', '0');
--
-- 6.59 measurement record from test_result where tst_unit_id = 281856, unit test from appendix: 221185 [Test ID: 219]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '646', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-11', '647', '4018', '1', '20471', '141', '646', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-10-11', '647', '0.0', '63745', '2011-10-11', '221185', '221185', '281856', '0.0', '0');
--
-- 6.60 measurement record from test_result where tst_unit_id = 281856, unit test from appendix: 221279 [Test ID: 220]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '649', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-14', '650', '4018', '1', '20471', '141', '649', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, low_normal_value, tra_id, tst_date, tst_id, tst_qual_id, tst_unit_id, tst_value, version) VALUES ('2011-10-14', '650', '0.0', '63745', '2011-10-14', '221279', '221279', '281856', '0.0', '0');
--
-- 6.61 measurement record from test_result, low high values [Test ID: 221]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '652', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-17', '653', '4018', '1', '20471', '141', '652', '8127', '36977', '0');
INSERT INTO test_result (con_date, con_id, high_normal_value, low_normal_value, tra_id, tst_date, tst_id, tst_unit_id, tst_value, version) VALUES ('2011-10-17', '653', '34', '27', '63745', '2011-10-17', '222512', '281690', '0.0', '0');
--
-- 6.62 measurement record from allergy, man_id: 10702 [Test ID: 222]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '655', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-20', '656', '4018', '1', '20471', '141', '655', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2011-10-20', '2010-09-11', '10702', '655', '-1', '37699', '0');
--
-- 6.63 measurement record from allergy, man_id: 10575 [Test ID: 223]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '658', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-23', '659', '4018', '1', '20471', '141', '658', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2011-10-23', '2010-09-11', '10575', '658', '-1', '37699', '0');
--
-- 6.64 measurement record from allergy, man_id: 11523 [Test ID: 224]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '661', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-26', '662', '4018', '1', '20471', '141', '661', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2011-10-26', '2010-09-11', '11523', '661', '-1', '37699', '0');
--
-- 6.65 measurement record from allergy, man_id: 12317 [Test ID: 225]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '664', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-10-29', '665', '4018', '1', '20471', '141', '664', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2011-10-29', '2010-09-11', '12317', '664', '-1', '37699', '0');
--
-- 6.66 measurement record from allergy, man_id: 11379 [Test ID: 226]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '667', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-01', '668', '4018', '1', '20471', '141', '667', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2011-11-01', '2010-09-11', '11379', '667', '-1', '37699', '0');
--
-- 6.67 measurement record from allergy, man_id: 10736 [Test ID: 227]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '670', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-04', '671', '4018', '1', '20471', '141', '670', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2011-11-04', '2010-09-11', '10736', '670', '-1', '37699', '0');
--
-- 6.68 measurement record from allergy, man_id: 11641 [Test ID: 228]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '673', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-07', '674', '4018', '1', '20471', '141', '673', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2011-11-07', '2010-09-11', '11641', '673', '-1', '37699', '0');
--
-- 6.69 measurement record from allergy including weight, date from input [Test ID: 229]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '676', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-10', '677', '4018', '1', '20471', '141', '676', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, man_id, pat_id, sev_id, tra_id, version, input_date) VALUES ('18648', '9999-12-31', '2772693', '14052', '676', '-1', '37699', '0', '2011-11-11');

-- 7. Observation Period
--
-- 7.0 condition_start_date as observation_period_start_date, measurement_date as observation_period_end_date [Test ID: 230]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1968', '2', '2', '680', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-13', '682', '4018', '1', '20471', '141', '680', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-11-13', '682', '376870', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-15', '684', '4018', '1', '20471', '141', '680', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-11-15', '684', '155751', '1', '100', '0', '63745', '0');
--
-- 7.1 measurement_date as observation_period_start_date, observation_date as observation_period_end_date [Test ID: 231]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1968', '2', '2', '685', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-18', '687', '4018', '1', '20471', '141', '685', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-11-18', '687', '155751', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-20', '689', '4018', '1', '20471', '141', '685', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-11-20', '689', '866944', '1', '100', '0', '63745', '0');
--
-- 7.2 procedure_date as observation_period_start_date, drug_exposure_start_date+1 as observation_period_end_date [Test ID: 232]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1968', '2', '2', '690', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-23', '692', '4018', '1', '20471', '141', '690', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-11-23', '692', '726097', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-25', '694', '4018', '1', '20471', '141', '690', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-11-25', '694', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 7.3 procedure_date as observation_period_start_date, drug_exposure_start_date+7 as observation_period_end_date [Test ID: 233]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1968', '2', '2', '695', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-28', '697', '4018', '1', '20471', '141', '695', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-11-28', '697', '726097', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-11-30', '699', '4018', '1', '20471', '141', '695', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-11-30', '699', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '7', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 7.4 procedure_date as observation_period_start_date, drug_exposure_start_date+14 as observation_period_end_date [Test ID: 234]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1968', '2', '2', '700', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-03', '702', '4018', '1', '20471', '141', '700', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-03', '702', '726097', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-05', '704', '4018', '1', '20471', '141', '700', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2011-12-05', '704', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '7', '0', '0', '0', '1', '0', '0', '1', '21672', '100', '17574271', '2', '5001', '37749', '30', '0');
--
-- 7.5 procedure_date as observation_period_start_date, drug_exposure_start_date+14 as observation_period_end_date [Test ID: 235]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1968', '2', '2', '705', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-08', '707', '4018', '1', '20471', '141', '705', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-08', '707', '55230', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-10', '709', '4018', '1', '20471', '141', '705', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-10', '709', '3017', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-12', '711', '4018', '1', '20471', '141', '705', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-12', '711', '155751', '1', '100', '0', '63745', '0');
--
-- 7.6 procedure_date as observation_period_start_date, death date as observation_period_end_date [Test ID: 1]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1968', '2', '2', '761', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-03', '7630', '4018', '1', '20471', '141', '761', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-03', '7630', '55230', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2010-01-05', '7650', '4018', '1', '20471', '141', '761', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2010-01-05', '7650', '3017', '1', '100', '0', '63745', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2020-01-01', '7660', '4018', '1', '20471', '141', '761', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2020-01-01', '7660', '155751', '1', '100', '0', '63745', '0');

-- 8. Observation
--
-- 8.0 basic diagnositic_contact ICD10 to observation test: 0R2620 [Test ID: 236]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '712', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-16', '713', '4018', '1', '20471', '141', '712', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-16', '713', '866944', '1', '100', '0', '63745', '0');
--
-- 8.1 basic diagnositic_contact ICD10 to observation test: 0R6330 [Test ID: 237]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '716', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-20', '717', '4018', '1', '20471', '141', '716', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-20', '717', '135105', '1', '100', '0', '63745', '0');
--
-- 8.2 basic diagnositic_contact ICD10 to observation test: 0R6300 [Test ID: 238]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '720', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-24', '721', '4018', '1', '20471', '141', '720', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-24', '721', '882', '1', '100', '0', '63745', '0');
--
-- 8.3 basic diagnositic_contact ICD10 to observation test: 0R6300 [Test ID: 239]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '724', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2011-12-28', '725', '4018', '1', '20471', '141', '724', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2011-12-28', '725', '143804', '1', '100', '0', '63745', '0');
--
-- 8.4 basic diagnositic_contact ICD10 to observation test: 0R6300 [Test ID: 240]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '728', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-01', '729', '4018', '1', '20471', '141', '728', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-01-01', '729', '744', '1', '100', '0', '63745', '0');
--
-- 8.5 basic diagnositic_contact ICD10 to observation test: 0H4000 [Test ID: 241]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '732', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-05', '733', '4018', '1', '20471', '141', '732', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-01-05', '733', '728985', '1', '100', '0', '63745', '0');
--
-- 8.6 basic diagnositic_contact ICD10 to observation test: 0Z6350 [Test ID: 242]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '736', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-09', '737', '4018', '1', '20471', '141', '736', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-01-09', '737', '10742', '1', '100', '0', '63745', '0');
--
-- 8.7 basic diagnositic_contact ICD10 to observation test: 0Z8620 [Test ID: 243]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '740', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-13', '741', '4018', '1', '20471', '141', '740', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-01-13', '741', '120241', '1', '100', '0', '63745', '0');
--
-- 8.8 basic prescription ICD10 to observation test: 0Z0450 [Test ID: 244]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '744', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-17', '745', '4018', '1', '20471', '141', '744', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-01-17', '745', '9090', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 8.9 basic prescription ICD10 to observation test: 0Z5010 [Test ID: 245]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '748', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-21', '749', '4018', '1', '20471', '141', '748', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-01-21', '749', '686596', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 8.10 basic prescription ICD10 to observation test: 0Z0120 [Test ID: 246]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '752', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-25', '753', '4018', '1', '20471', '141', '752', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-01-25', '753', '3110', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 8.11 basic prescription ICD10 to observation test: 0Z5050 [Test ID: 247]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '756', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-01-29', '757', '4018', '1', '20471', '141', '756', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-01-29', '757', '325113', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 8.12 basic prescription ICD10 to observation test: 0Z7130 [Test ID: 248]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '760', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-02-02', '761', '4018', '1', '20471', '141', '760', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-02-02', '761', '13564', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 8.13 basic prescription ICD10 to observation test: 0Z7130 [Test ID: 249]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '764', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-02-06', '765', '4018', '1', '20471', '141', '764', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-02-06', '765', '3917', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 8.14 prescription to observation test: 0R6300 [Test ID: 250]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '768', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-02-10', '769', '4018', '1', '20471', '141', '768', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('9301', '2012-11-12', '2012-02-10', '768', '27881', '0');
--
-- 8.15 prescription to observation test: 0H4000 [Test ID: 251]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '772', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-02-14', '773', '4018', '1', '20471', '141', '772', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('604483', '2012-11-12', '2012-02-14', '772', '27881', '0');
--
-- 8.16 prescription to observation test: 0Z6350 [Test ID: 252]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '776', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-02-18', '777', '4018', '1', '20471', '141', '776', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('204549', '2012-11-12', '2012-02-18', '776', '27881', '0');
--
-- 8.17 prescription to observation test: 0Z8660 [Test ID: 253]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '780', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-02-22', '781', '4018', '1', '20471', '141', '780', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('261239', '2012-11-12', '2012-02-22', '780', '27881', '0');
--
-- 8.18 prescription to observation test: 0Z9150 [Test ID: 254]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '784', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-02-26', '785', '4018', '1', '20471', '141', '784', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('374918', '2012-11-12', '2012-02-26', '784', '27881', '0');
--
-- 8.19 prescription to observation test: 0Z9150 [Test ID: 255]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '788', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-01', '789', '4018', '1', '20471', '141', '788', '8127', '36977', '0');
INSERT INTO patient_medical_hist (dia_id, input_date, known_since, pat_id, tra_id, version) VALUES ('11446', '2012-11-12', '2012-03-01', '788', '27881', '0');
--
-- 8.20 Admits alcohol use record from biometric, src.locale_list_code.lco_long_label=1 [Test ID: 256]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '792', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-05', '793', '4018', '1', '20471', '141', '792', '8127', '36977', '0');
INSERT INTO biometric (alc_id, alcohol_drinker, con_date, con_id, dayly_cigaret_number, is_smoker, min_bp, tra_id, version) VALUES ('20609', '0', '2012-03-05', '793', '0', '0', '80', '52164', '0');
--
-- 8.21 Admits alcohol use record from biometric, src.locale_list_code.lco_long_label=0 [Test ID: 257]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '795', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-08', '796', '4018', '1', '20471', '141', '795', '8127', '36977', '0');
INSERT INTO biometric (alc_id, alcohol_drinker, con_date, con_id, dayly_cigaret_number, is_smoker, min_bp, tra_id, version) VALUES ('20608', '0', '2012-03-08', '796', '0', '0', '80', '52164', '0');
--
-- 8.22 observation record from allergy, alg_id: 17936 [Test ID: 258]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '798', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-11', '799', '4018', '1', '20471', '141', '798', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('17936', '9999-12-31', '2772693', '2012-03-11', '2010-09-11', '-1', '798', '-1', '37699', '0');
--
-- 8.23 observation record from allergy, alg_id: 270542 [Test ID: 259]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '802', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-15', '803', '4018', '1', '20471', '141', '802', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('270542', '9999-12-31', '2772693', '2012-03-15', '2010-09-11', '-1', '802', '-1', '37699', '0');
--
-- 8.24 observation record from allergy, alg_id: 17936 [Test ID: 260]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '806', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-19', '807', '4018', '1', '20471', '141', '806', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('17936', '9999-12-31', '2772693', '2012-03-19', '2010-09-11', '-1', '806', '-1', '37699', '0');
--
-- 8.25 observation record from allergy, alg_id: 270542 [Test ID: 261]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '810', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-23', '811', '4018', '1', '20471', '141', '810', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('270542', '9999-12-31', '2772693', '2012-03-23', '2010-09-11', '-1', '810', '-1', '37699', '0');
--
-- 8.26 observation record from allergy, man_id: 11643 [Test ID: 262]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '814', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-27', '815', '4018', '1', '20471', '141', '814', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2012-03-27', '2010-09-11', '11643', '814', '-1', '37699', '0');
--
-- 8.27 observation record from allergy, man_id: 10379 [Test ID: 263]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '818', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-03-31', '819', '4018', '1', '20471', '141', '818', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2012-03-31', '2010-09-11', '10379', '818', '-1', '37699', '0');
--
-- 8.28 observation record from allergy, man_id: 13356 [Test ID: 264]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '822', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-04-04', '823', '4018', '1', '20471', '141', '822', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2012-04-04', '2010-09-11', '13356', '822', '-1', '37699', '0');
--
-- 8.29 observation record from allergy, man_id: 13277 [Test ID: 265]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '826', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-04-08', '827', '4018', '1', '20471', '141', '826', '8127', '36977', '0');
INSERT INTO allergy (alg_id, all_end_date, all_id, all_start_date, input_date, man_id, pat_id, sev_id, tra_id, version) VALUES ('18648', '9999-12-31', '2772693', '2012-04-08', '2010-09-11', '13277', '826', '-1', '37699', '0');

-- 9. Person
--
-- 9.0 Patient gender = male [Test ID: 266]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '1', '830', '24824', '0');
--
-- 9.1 Patient gender = female [Test ID: 267]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '831', '24824', '0');
--
-- 9.2 Patient gender = unknown [Test ID: 268]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '-1', '832', '24824', '0');
--
-- 9.3 Patient year_of_birth < 1900 if birthyear_od < 1900 [Test ID: 269]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1890', '2', '2', '833', '24824', '0');
--
-- 9.4 Patient year_of_birth > 2016 if birthyear_od > 2016 [Test ID: 270]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '2020', '2', '2', '834', '24824', '0');
--
-- 9.5 Patient missing year of birth, drop [Test ID: 271]
--
INSERT INTO patient (birth_month, birth_year, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '2', '2', '835', '24824', '0');

-- 10. Procedure Occurrence
--
-- 10.0 basic diagnositic_contact ICD10 to procedure_occurrence test: 0Z0180 [Test ID: 272]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '836', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-04-18', '837', '4018', '1', '20471', '141', '836', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-04-18', '837', '726097', '1', '100', '0', '63745', '0');
--
-- 10.1 basic diagnositic_contact ICD10 to procedure_occurrence test: 0Z0040 [Test ID: 273]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '839', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-04-21', '840', '4018', '1', '20471', '141', '839', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-04-21', '840', '208979', '1', '100', '0', '63745', '0');
--
-- 10.2 basic diagnositic_contact ICD10 to procedure_occurrence test: 0R8290 [Test ID: 274]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '842', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-04-24', '843', '4018', '1', '20471', '141', '842', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-04-24', '843', '384842', '1', '100', '0', '63745', '0');
--
-- 10.3 basic diagnositic_contact ICD10 to procedure_occurrence test: 0Z1230 [Test ID: 275]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '845', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-04-27', '846', '4018', '1', '20471', '141', '845', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-04-27', '846', '41523', '1', '100', '0', '63745', '0');
--
-- 10.4 2 diagnostic_contact dia_ids map to one  ICD10, keep 1 procedure_occurrence record [Test ID: 276]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '848', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-04-30', '849', '4018', '1', '20471', '141', '848', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-04-30', '849', '346604', '1', '100', '0', '63745', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-04-30', '849', '10812', '1', '100', '0', '63745', '0');
--
-- 10.5 basic diagnostic_contact procedure_occurrence record with provider_id, procedure_type_concept_id [Test ID: 277]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '851', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('852', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-05-04', '853', '4018', '1', '20471', '852', '851', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-05-04', '853', '348378', '1', '100', '0', '63745', '0');
--
-- 10.6 basic prescription ICD10 to procedure_occurrence test: 0R3100 [Test ID: 278]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '855', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-05-07', '856', '4018', '1', '20471', '141', '855', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-05-07', '856', '148265', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 10.7 basic prescription ICD10 to procedure_occurrence test: 0Z0180 [Test ID: 279]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '858', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-05-10', '859', '4018', '1', '20471', '141', '858', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-05-10', '859', '52646', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 10.8 basic prescription ICD10 to procedure_occurrence test: 0O0490 [Test ID: 280]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '861', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-05-13', '862', '4018', '1', '20471', '141', '861', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-05-13', '862', '12579', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 10.9 basic prescription ICD10 to procedure_occurrence test: 0Z3000 [Test ID: 281]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '864', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-05-16', '865', '4018', '1', '20471', '141', '864', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-05-16', '865', '233863', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 10.10 2 prescription dia_ids map to one  ICD10, keep 1 procedure_occurrence record [Test ID: 282]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '867', '24824', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-05-19', '868', '4018', '1', '20471', '141', '867', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-05-19', '868', '91884', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-05-19', '868', '262864', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 10.11 basic prescription procedure_occurrence record with provider_id, procedure_type_concept_id [Test ID: 283]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '870', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('871', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-05-23', '872', '4018', '1', '20471', '871', '870', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-05-23', '872', '148265', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588564', '100', '17574271', '0', '5001', '37749', '30', '0');

-- 11. Provider
--
-- 11.0 Provider specialty test: ADMINISTRATION [Test ID: 284]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('874', '2013-10-11', 'en', '20610', '20498', '40795', '0');
--
-- 11.1 Provider specialty test: DIABETES EDUCATOR [Test ID: 285]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('875', '2013-10-11', 'en', '20610', '20501', '40795', '0');
--
-- 11.2 Provider specialty test: DIETITIAN [Test ID: 286]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('876', '2013-10-11', 'en', '20610', '20502', '40795', '0');
--
-- 11.3 Provider specialty test: DOCTOR [Test ID: 287]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('877', '2013-10-11', 'en', '20610', '20503', '40795', '0');
--
-- 11.4 Provider specialty test: ENROLLED NURSE [Test ID: 288]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('878', '2013-10-11', 'en', '20610', '20505', '40795', '0');
--
-- 11.5 Provider specialty test: EXERCISE PHYSIOLOGIST [Test ID: 289]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('879', '2013-10-11', 'en', '20610', '20615', '40795', '0');
--
-- 11.6 Provider specialty test: GENERAL PRACTITIONER [Test ID: 290]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('880', '2013-10-11', 'en', '20610', '20658', '40795', '0');
--
-- 11.7 Provider specialty test: LOCUM TENENS [Test ID: 291]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('881', '2013-10-11', 'en', '20610', '20634', '40795', '0');
--
-- 11.8 Provider specialty test: MIDWIFE [Test ID: 292]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('882', '2013-10-11', 'en', '20610', '20510', '40795', '0');
--
-- 11.9 Provider specialty test: NURSE [Test ID: 293]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('883', '2013-10-11', 'en', '20610', '20511', '40795', '0');
--
-- 11.10 Provider specialty test: OTHER [Test ID: 294]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('884', '2013-10-11', 'en', '20610', '20624', '40795', '0');
--
-- 11.11 Provider specialty test: PHLEBOTOMIST [Test ID: 295]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('885', '2013-10-11', 'en', '20610', '20515', '40795', '0');
--
-- 11.12 Provider specialty test: PHYSIOTHERAPIST [Test ID: 296]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('886', '2013-10-11', 'en', '20610', '20516', '40795', '0');
--
-- 11.13 Provider specialty test: PRACTICE MANAGER [Test ID: 297]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('887', '2013-10-11', 'en', '20610', '20518', '40795', '0');
--
-- 11.14 Provider specialty test: PSYCHIATRIST [Test ID: 298]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('888', '2013-10-11', 'en', '20610', '20520', '40795', '0');
--
-- 11.15 Provider specialty test: PSYCHOLOGIST [Test ID: 299]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('889', '2013-10-11', 'en', '20610', '20521', '40795', '0');
--
-- 11.16 Provider specialty test: RECEPTION [Test ID: 300]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('890', '2013-10-11', 'en', '20610', '20618', '40795', '0');
--
-- 11.17 Provider specialty test: RECEPTIONIST [Test ID: 301]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('891', '2013-10-11', 'en', '20610', '20522', '40795', '0');
--
-- 11.18 Provider specialty test: REGISTERED NURSE [Test ID: 302]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('892', '2013-10-11', 'en', '20610', '20523', '40795', '0');
--
-- 11.19 Provider specialty test: SOCIAL WORKER [Test ID: 303]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('893', '2013-10-11', 'en', '20610', '20659', '40795', '0');
--
-- 11.20 Provider specialty test: STAFF [Test ID: 304]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('894', '2013-10-11', 'en', '20610', '20524', '40795', '0');
--
-- 11.21 Provider specialty test: STUDENT [Test ID: 305]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('895', '2013-10-11', 'en', '20610', '20508', '40795', '0');
--
-- 11.22 Provider specialty test: WOMEN'S HEALTH NURSE [Test ID: 306]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('896', '2013-10-11', 'en', '20610', '20639', '40795', '0');
--
-- 11.23 Care site ID from doctor_practice.pra_id [Test ID: 307]
--
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('897', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO practice (pra_id, state, postcode) VALUES ('22127', 'NSW', '5100-5109');
INSERT INTO doctor_practice (doc_id, pra_id, rank, tra_id, version) VALUES ('897', '22127', '1', '24612', '0');
--
-- 11.24 Doctor gender = male [Test ID: 308]
--
INSERT INTO doctor (doc_gen_id, doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('1', '898', '2013-10-11', 'en', '20610', '20503', '40795', '0');
--
-- 11.25 Doctor gender = female [Test ID: 309]
--
INSERT INTO doctor (doc_gen_id, doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('2', '899', '2013-10-11', 'en', '20610', '20503', '40795', '0');

-- 12. Visit Occurrence
--
-- 12.0 visit occurrence record from procedure_occurrence, with provider [Test ID: 310]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '900', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('901', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-06-22', '902', '4018', '1', '20471', '901', '900', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-06-22', '902', '726097', '1', '100', '0', '63745', '0');
--
-- 12.1 visit occurrence record from drug_exposure, with provider [Test ID: 311]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '904', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('905', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-06-26', '906', '4018', '1', '20471', '905', '904', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-06-26', '906', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '603035', '100', '17574271', '0', '5001', '37749', '30', '0');
--
-- 12.2 visit occurrence record from condition_occurrence, with provider [Test ID: 312]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '908', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('909', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-06-30', '910', '4018', '1', '20471', '909', '908', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-06-30', '910', '376870', '1', '100', '0', '63745', '0');
--
-- 12.3 visit occurrence record from measurement, with provider [Test ID: 313]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '912', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('913', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-07-04', '914', '4018', '1', '20471', '913', '912', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-07-04', '914', '155751', '1', '100', '0', '63745', '0');
--
-- 12.4 visit occurrence record from observation, with provider [Test ID: 314]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '916', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('917', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-07-08', '918', '4018', '1', '20471', '917', '916', '8127', '36977', '0');
INSERT INTO diagnostic_contact (con_date, con_id, dia_id, dia_rank, dia_type_id, is_professional_disease, tra_id, version) VALUES ('2012-07-08', '918', '866944', '1', '100', '0', '63745', '0');
--
-- 12.5 visit occurrence record from device, with provider [Test ID: 315]
--
INSERT INTO patient (birth_month, birth_year, birthyear_od, gen_id, gen_id_od, pat_id, tra_id, version) VALUES ('1', '1983', '1983', '2', '2', '920', '24824', '0');
INSERT INTO doctor (doc_id, last_trans_date, lng_code, rol_id, spe_id, tra_id, version) VALUES ('921', '2013-10-11', 'en', '20610', '20503', '40795', '0');
INSERT INTO contact (con_date, con_id, con_mar_id, con_num, con_typ_id, doc_id, pat_id, pra_id, tra_id, version) VALUES ('2012-07-12', '922', '4018', '1', '20471', '921', '920', '8127', '36977', '0');
INSERT INTO prescription (con_date, con_id, dia_id, in_prevention, is_long_period_disease, is_private, max_dosage, max_dosage2, max_dosage3, max_duration_in_days, max_duration_in_days2, max_duration_in_days3, max_duration_orig, max_per_period, max_per_period2, max_per_period3, min_dosage, min_dosage2, min_dosage3, min_duration_in_days, min_duration_in_days2, min_duration_in_days3, min_duration_orig, min_per_period, min_per_period2, min_per_period3, per_id, prd_id, pre_dia_type_id, pre_id, renewal_number, substitut_id, tra_id, trt_duration_tabs, version) VALUES ('2012-07-12', '922', '-1', '0', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '0', '0', '30', '0', '0', '0', '1', '0', '0', '1', '588407', '100', '17574271', '0', '5001', '37749', '30', '0');